import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Footer } from "@/components/footer"
import { Header } from "@/components/header"
import { Heart, Lightbulb, MessageSquare, Smile, Star, Zap } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-16 md:py-24 px-4 pattern-bg">
          <div className="container mx-auto max-w-6xl">
            <div className="flex flex-col md:flex-row items-center gap-8 md:gap-16">
              <div className="md:w-1/2 space-y-6">
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-800 leading-tight">
                  A Respectful Copilot for <span className="text-primary">Inclusive Independence</span>
                </h1>
                <p className="text-lg md:text-xl text-gray-600">
                  CoCare helps caregivers focus on care, not notes. Smart logging, child-friendly expression tools, and
                  a warm design that grows with each individual.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 pt-4">
                  <Button size="lg" className="bounce-hover glow-hover">
                    <Link href="/login">Try the Portal</Link>
                  </Button>
                  <Button size="lg" variant="outline" className="bounce-hover bg-transparent">
                    <Link href="#how-it-works">See How It Works</Link>
                  </Button>
                </div>
              </div>
              <div className="md:w-1/2 mt-8 md:mt-0">
                <div className="relative">
                  <div className="absolute -inset-4 bg-gradient-to-r from-secondary via-primary to-accent rounded-xl blur-xl opacity-30 animate-pulse"></div>
                  <Card className="overflow-hidden border-2 border-primary/20">
                    <CardContent className="p-0">
                      <img
                        src="/placeholder.svg?height=400&width=600"
                        alt="Caregiver and child using CoCare together"
                        className="w-full h-auto rounded-lg"
                      />
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="how-it-works" className="py-16 md:py-24 px-4">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">How CoCare Works</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Our platform is designed to make caregiving more intuitive, joyful, and effective.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {features.map((feature, index) => (
                <Card
                  key={index}
                  className="overflow-hidden border-2 border-primary/10 hover:border-primary/30 transition-all duration-300 bounce-hover"
                >
                  <CardContent className="p-6 flex flex-col items-center text-center">
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                    <p className="text-gray-600">{feature.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-16 md:py-24 px-4 bg-secondary/20">
          <div className="container mx-auto max-w-6xl">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Stories from Our Community</h2>
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                Hear from caregivers who have transformed their daily routines with CoCare.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {testimonials.map((testimonial, index) => (
                <Card key={index} className="overflow-hidden border-2 border-secondary/30">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="h-12 w-12 rounded-full bg-secondary/30 flex items-center justify-center mr-4">
                        <span className="font-bold text-lg">{testimonial.name.charAt(0)}</span>
                      </div>
                      <div>
                        <h4 className="font-bold">{testimonial.name}</h4>
                        <p className="text-sm text-gray-600">{testimonial.role}</p>
                      </div>
                    </div>
                    <p className="text-gray-700 italic">"{testimonial.quote}"</p>
                    <div className="flex mt-4">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-yellow-400 fill-yellow-400" />
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 md:py-24 px-4">
          <div className="container mx-auto max-w-6xl">
            <Card className="overflow-hidden border-2 border-accent/30 bg-accent/10">
              <CardContent className="p-8 md:p-12">
                <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                  <div className="md:w-2/3">
                    <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to transform your caregiving journey?</h2>
                    <p className="text-lg text-gray-600">
                      Join our community of caregivers and experience the difference that thoughtful technology can
                      make.
                    </p>
                  </div>
                  <div className="md:w-1/3 flex justify-center">
                    <Button size="lg" className="text-lg px-8 py-6 bounce-hover glow-hover wiggle-hover">
                      <Link href="/login">Get Started Today</Link>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

const features = [
  {
    title: "Smart Logging",
    description: "Automatically generate summaries of activities and moods, saving you time and mental energy.",
    icon: Zap,
  },
  {
    title: "Child Expression UI",
    description: "An accessible interface that helps children communicate their needs and preferences.",
    icon: Smile,
  },
  {
    title: "Progress Insights",
    description: "Visualize patterns and progress over time with easy-to-understand charts and timelines.",
    icon: Lightbulb,
  },
  {
    title: "Emergency Toolkit",
    description: "Quick access to calming strategies and emergency contacts when you need them most.",
    icon: Heart,
  },
  {
    title: "Voice Notes",
    description: "Record your observations on the go, and let CoCare transform them into organized logs.",
    icon: MessageSquare,
  },
  {
    title: "Personalized Support",
    description: "Receive tailored suggestions based on your child's unique patterns and preferences.",
    icon: Star,
  },
]

const testimonials = [
  {
    name: "Jamie Rodriguez",
    role: "Parent of a child with autism",
    quote:
      "CoCare has transformed our daily routine. I can finally see patterns in my son's behavior that I was missing before, and the expression tools have given him a voice when words are difficult.",
  },
  {
    name: "Taylor Morgan",
    role: "Special education teacher",
    quote:
      "As someone who works with multiple children, the ability to quickly log activities and share insights with parents has been invaluable. The interface is so intuitive that I can focus on the children, not the technology.",
  },
]
