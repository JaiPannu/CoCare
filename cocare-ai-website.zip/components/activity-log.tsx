import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { MoodTracker } from "@/components/mood-tracker"
import { Check, Edit, MoreHorizontal, Trash } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function ActivityLog() {
  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Recent Activity Logs</h3>

      {activityLogs.map((log, index) => (
        <Card key={index} className={`border-l-4 ${log.borderColor}`}>
          <CardContent className="p-4">
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-muted flex items-center justify-center">
                  <MoodTracker mood={log.mood} size="sm" />
                </div>
                <div>
                  <p className="font-medium">{log.time}</p>
                  <p className="text-sm text-gray-500">{log.duration}</p>
                </div>
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <MoreHorizontal className="h-4 w-4" />
                    <span className="sr-only">More options</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>
                    <Edit className="mr-2 h-4 w-4" /> Edit
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-red-500">
                    <Trash className="mr-2 h-4 w-4" /> Delete
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            <div className="mt-3">
              <p>{log.description}</p>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {log.tags.map((tag, tagIndex) => (
                <span
                  key={tagIndex}
                  className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                >
                  {tag}
                </span>
              ))}
            </div>

            {log.suggestion && (
              <div className="mt-3 p-2 bg-purple-50 rounded-md text-sm">
                <p className="font-medium text-purple-700">Suggestion:</p>
                <p className="text-purple-800">{log.suggestion}</p>
              </div>
            )}

            <div className="mt-3 flex justify-end gap-2">
              <Button variant="outline" size="sm">
                <Edit className="mr-2 h-3 w-3" /> Edit
              </Button>
              <Button size="sm">
                <Check className="mr-2 h-3 w-3" /> Confirm
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

const activityLogs = [
  {
    time: "11:15 AM",
    duration: "25 minutes",
    description: "Sam played with building blocks. Built a tower and knocked it down repeatedly. Laughed and engaged well.",
    mood: "happy",
    tags: ["Play Time", "Building", "Engaged"],
    borderColor: "border-green-400",
  },
  {
    time: "10:30 AM",
    duration: "15 minutes",
    description: "Snack time. Sam ate apple slices and drank water. Seemed a bit distracted but finished most of the snack.",
    mood: "neutral",
    tags: ["Snack Time", "Eating"],
    suggestion: "Try using the blue plate next time - Sam seems to focus better with it.",
    borderColor: "border-blue-400",
  },
  {
    time: "9:45 AM",\
    duration: "20
