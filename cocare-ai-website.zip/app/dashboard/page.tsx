"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardSidebar } from "@/components/dashboard-sidebar"
import { ActivityLog } from "@/components/activity-log"
import { MoodTracker } from "@/components/mood-tracker"
import { EmergencyToolkit } from "@/components/emergency-toolkit"
import { ChildExpressionUI } from "@/components/child-expression-ui"
import { Calendar, Check, Clock, Edit, Mic, Plus } from "lucide-react"

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState("summary")

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <DashboardSidebar />

      <div className="flex-1">
        <DashboardHeader />

        <main className="p-4 md:p-6 max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold mb-2">Welcome back, Alex</h1>
            <p className="text-gray-600">Tuesday, July 16 • Let&apos;s make today count!</p>
          </div>

          <Tabs defaultValue="summary" className="mb-8" onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="summary">Summary</TabsTrigger>
              <TabsTrigger value="log">Log</TabsTrigger>
              <TabsTrigger value="timeline">Timeline</TabsTrigger>
            </TabsList>

            <TabsContent value="summary">
              <Card className="border-2 border-primary/20 wave-animation">
                <CardHeader>
                  <CardTitle>Today&apos;s Snapshot</CardTitle>
                  <CardDescription>A quick overview of Sam&apos;s day so far</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center gap-4 p-3 bg-blue-50 rounded-lg border border-blue-100">
                    <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                      <Clock className="h-5 w-5 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">Child Playing: 18 mins</p>
                      <p className="text-sm text-gray-600">Building blocks and drawing</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-3 bg-green-50 rounded-lg border border-green-100">
                    <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center">
                      <MoodTracker mood="calm" size="sm" />
                    </div>
                    <div>
                      <p className="font-medium">Mood: Calm</p>
                      <p className="text-sm text-gray-600">Consistent for the past 2 hours</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-4 p-3 bg-purple-50 rounded-lg border border-purple-100">
                    <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center">
                      <Calendar className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Suggestion</p>
                      <p className="text-sm text-gray-600">Add calming music during the next activity?</p>
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between border-t pt-4">
                  <Button variant="outline" className="flex-1 mr-2 bg-transparent">
                    <Mic className="mr-2 h-4 w-4" /> Voice Note
                  </Button>
                  <Button className="flex-1 ml-2">
                    <Plus className="mr-2 h-4 w-4" /> New Log
                  </Button>
                </CardFooter>
              </Card>
            </TabsContent>

            <TabsContent value="log">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle>Smart Log</CardTitle>
                  <CardDescription>Auto-suggested summary (editable)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="p-4 bg-muted rounded-lg mb-4">
                    <p className="text-lg">
                      Sam played with building blocks for 14 minutes. Seemed overstimulated after loud music.
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-2 mb-4">
                    <Button variant="outline" size="sm" className="rounded-full bg-transparent">
                      Snack time
                    </Button>
                    <Button variant="outline" size="sm" className="rounded-full bg-transparent">
                      Quiet time
                    </Button>
                    <Button variant="outline" size="sm" className="rounded-full bg-transparent">
                      Frustrated
                    </Button>
                    <Button variant="outline" size="sm" className="rounded-full bg-transparent">
                      <Plus className="h-3 w-3 mr-1" /> Add tag
                    </Button>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between border-t pt-4">
                  <Button variant="outline" className="flex-1 mr-2 bg-transparent">
                    <Edit className="mr-2 h-4 w-4" /> Edit
                  </Button>
                  <Button className="flex-1 ml-2">
                    <Check className="mr-2 h-4 w-4" /> Confirm
                  </Button>
                </CardFooter>
              </Card>

              <div className="mt-6">
                <ActivityLog />
              </div>
            </TabsContent>

            <TabsContent value="timeline">
              <Card className="border-2 border-primary/20">
                <CardHeader>
                  <CardTitle>Daily Timeline</CardTitle>
                  <CardDescription>Track activities and moods throughout the day</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {timelineItems.map((item, index) => (
                      <div key={index} className="flex">
                        <div className="mr-4 flex flex-col items-center">
                          <div className="text-sm font-medium text-gray-500">{item.time}</div>
                          <div className="h-full w-0.5 bg-border mt-2"></div>
                        </div>
                        <div className="pb-6">
                          <div className={`p-3 rounded-lg border ${item.bgColor}`}>
                            <div className="font-medium">{item.title}</div>
                            <div className="text-sm text-gray-600 mt-1">{item.description}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border-2 border-primary/20">
              <CardHeader>
                <CardTitle>Child Expression</CardTitle>
                <CardDescription>Help Sam communicate needs and preferences</CardDescription>
              </CardHeader>
              <CardContent>
                <ChildExpressionUI />
              </CardContent>
            </Card>

            <Card className="border-2 border-accent/20">
              <CardHeader>
                <CardTitle>Emergency Toolkit</CardTitle>
                <CardDescription>Quick access to support resources</CardDescription>
              </CardHeader>
              <CardContent>
                <EmergencyToolkit />
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}

const timelineItems = [
  {
    time: "9:00 AM",
    title: "Morning Routine",
    description: "Breakfast and getting ready for the day",
    bgColor: "bg-blue-50 border-blue-100",
  },
  {
    time: "10:30 AM",
    title: "Play Time",
    description: "Building blocks and drawing (18 minutes)",
    bgColor: "bg-green-50 border-green-100",
  },
  {
    time: "11:15 AM",
    title: "Snack Break",
    description: "Had apple slices and water",
    bgColor: "bg-yellow-50 border-yellow-100",
  },
  {
    time: "12:00 PM",
    title: "Rest Period",
    description: "Quiet time with books",
    bgColor: "bg-purple-50 border-purple-100",
  },
]
