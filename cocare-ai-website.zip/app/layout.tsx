import type React from "react"
import type { Metadata } from "next"
import { Nunito } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"

const nunito = Nunito({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "CoCare AI | A Respectful Copilot for Inclusive Independence",
  description:
    "CoCare helps caregivers focus on care, not notes. Smart logging, child-friendly expression tools, and a warm design that grows with each individual.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={nunito.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
          {children}
        </ThemeProvider>
      </body>
    </html>
  )
}
